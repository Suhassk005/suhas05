echo enter a color red green black
read color
if [ $color = red ]
then 
echo you are lucky
elif [ $color = green ]
then 
echo  your are cheerfull
else 
echo you are both
fi