i=10
while [ $i -gt 0 ]
do
echo revarse oedr number $i
i=$((i-1))
done