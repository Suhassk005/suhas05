echo enter your age 
read age
if [ $age -gt 17 ]
then 
echo you  are eligable
else
echo you are not
fi